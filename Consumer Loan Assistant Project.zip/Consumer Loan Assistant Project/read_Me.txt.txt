# Consumer Loan Assistant Project
# Problem statement : How does one calculate the loan interest, within how many periods he has to pay?

# Abstract : The Consumer Loan Assistant Project helps you keep track of your loans from a bank or any other resource. 
            For every purpose in the inventory, the program stores a amount of loan,
            interest rate,number of payment , monthly payments, and a calculation displayer.
            A printed inventory is available - very useful for insurance purposes.
            This coding Internship project would re-inforce some object-oriented programming concepts and how to print from a project.